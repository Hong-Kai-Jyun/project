<?php

phpinfo();

?>
