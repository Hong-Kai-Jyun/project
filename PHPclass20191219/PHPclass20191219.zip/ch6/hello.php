<!doctype html>
    <html lang="en">
      <head>
        <title>Hello World</title>
      </head>
      <body>
          <?php
            print "Hello World";
          ?>
      </body>
    </html>