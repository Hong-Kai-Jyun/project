<?php
    echo "Hello <br />";
    echo 'World <br />';
    print "Hello2 <br />";
    print 'World2 <br />';
    printf("Hello World");
?>